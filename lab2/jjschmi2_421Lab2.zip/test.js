//var serv = require("./NewsService.js")
//var ns = new serv.NewsService();
//ns.createNews("title", "author", "date", "pub", "content");
//ns.updateHeadline("newtitle", "difftitle");
//ns.updateNews("difftitle", "diffauthor", "diffdate", "diffpub", "diffcontent");
//ns.getNews("title", undefined, undefined, undefined, undefined));
